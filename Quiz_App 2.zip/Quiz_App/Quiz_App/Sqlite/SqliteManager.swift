//
//  SqliteManager.swift
//  Quiz_App
//
//  Created by devsenior on 18/02/2024.
//

import Foundation
import SQLite

class SqliteManager {
    static let shared = SqliteManager() // Singleton instance
    private let db: Connection?
    
    private let scoresTable = Table("scores")
    private let id = Expression<Int>("id")
    private let score = Expression<Int>("score")
    
    private let challengesTable = Table("challenges")
    private let level = Expression<String>("level")
    private let unlocked = Expression<Bool>("unlocked")
    
    private init() {
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first!
        do {
            db = try Connection("\(path)/db.sqlite3")
            createTable()
        } catch {
            db = nil
            print("Không thể kết nối đến cơ sở dữ liệu: \(error)")
        }
    }
    
    private func createTable() {
        let createTable = scoresTable.create(ifNotExists: true) { (table) in
            table.column(id, primaryKey: true)
            table.column(score)
        }

        do {
            try db?.run(createTable)
            print("Tạo bảng thành công hoặc bảng đã tồn tại")
        } catch {
            print("Không thể tạo bảng: \(error)")
        }
    }
    
    func saveScore(playerScore: PlayerScore) {
        let insert = scoresTable.insert(self.score <- playerScore.score)
        do {
            let rowId = try db?.run(insert)
            print("Lưu điểm số thành công")
        } catch {
            print("Không thể lưu điểm số: \(error)")
        }
    }
    
    func getTotalScore() -> Int {
          do {
              let sum = try db?.scalar(scoresTable.select(score.sum)) ?? 0
              return sum
          } catch {
              print("Không thể lấy tổng điểm số: \(error)")
              return 0
          }
      }
    
    func addScore(points: Int) {
        let insert = scoresTable.insert(self.score <- points)
        do {
            let _ = try db?.run(insert)
            print("Thêm điểm thành công")
        } catch {
            print("Không thể thêm điểm: \(error)")
        }
    }
}
