//
//  Constans.swift
//  Quiz_App
//
//  Created by devsenior on 03/02/2024.
//

import Foundation
import UIKit

struct Constants {
    static let filmUrl_lv1 = "https://opentdb.com/api.php?amount=5&category=11&difficulty=easy&type=multiple"
    static let filmUrl_lv2 = "https://opentdb.com/api.php?amount=5&category=11&difficulty=medium&type=multiple"
    static let filmUrl_lv3 = "https://opentdb.com/api.php?amount=7&category=11&difficulty=medium&type=multiple"
    static let filmUrl_lv4 = "https://opentdb.com/api.php?amount=7&category=11&difficulty=hard&type=multiple"
    static let filmUrl_lv5 = "https://opentdb.com/api.php?amount=10&category=11&difficulty=hard&type=multiple"
    
    static let musicUrl_lv1 = "https://opentdb.com/api.php?amount=5&category=11&difficulty=easy&type=multiple"
    static let musicUrl_lv2 = "https://opentdb.com/api.php?amount=5&category=11&difficulty=medium&type=multiple"
    static let musicUrl_lv3 = "https://opentdb.com/api.php?amount=7&category=11&difficulty=medium&type=multiple"
    static let musicUrl_lv4 = "https://opentdb.com/api.php?amount=7&category=11&difficulty=hard&type=multiple"
    static let musicUrl_lv5 = "https://opentdb.com/api.php?amount=10&category=11&difficulty=hard&type=multiple"
    
    static let tvUrl_lv1 = "https://opentdb.com/api.php?amount=5&category=11&difficulty=easy&type=multiple"
    static let tvUrl_lv2 = "https://opentdb.com/api.php?amount=5&category=11&difficulty=medium&type=multiple"
    static let tvUrl_lv3 = "https://opentdb.com/api.php?amount=7&category=11&difficulty=medium&type=multiple"
    static let tvUrl_lv4 = "https://opentdb.com/api.php?amount=7&category=11&difficulty=hard&type=multiple"
    static let tvUrl_lv5 = "https://opentdb.com/api.php?amount=10&category=11&difficulty=hard&type=multiple"
    
    static let historyUrl_lv1 = "https://opentdb.com/api.php?amount=5&category=11&difficulty=easy&type=multiple"
    static let historyUrl_lv2 = "https://opentdb.com/api.php?amount=5&category=11&difficulty=medium&type=multiple"
    static let historyUrl_lv3 = "https://opentdb.com/api.php?amount=7&category=11&difficulty=medium&type=multiple"
    static let historyUrl_lv4 = "https://opentdb.com/api.php?amount=7&category=11&difficulty=hard&type=multiple"
    static let historyUrl_lv5 = "https://opentdb.com/api.php?amount=10&category=11&difficulty=hard&type=multiple"
    
    static let isSoundEnabled = "isSoundEnabled"
    static let isSoundOn = "isSoundOn"
    static let heightMenu = CGFloat(200)
}


