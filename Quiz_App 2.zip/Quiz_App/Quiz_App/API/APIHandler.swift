//
//  APIHandler.swift
//  Quiz_App
//
//  Created by devsenior on 03/02/2024.
//

import Foundation
import Alamofire

class APIHandler: NSObject {
    func getData(from url: String, completion: @escaping (Swift.Result<Quiz, Error>) -> Void) {
        let headers: HTTPHeaders = ["Content-Type": "application/json"]

        AF.request(url, method: .get, parameters: nil, encoding: URLEncoding.default, headers: headers).responseData { response in
            switch response.result {
            case .success(let data):
                do {
                    let quizData = try JSONDecoder().decode(Quiz.self, from: data)
                    completion(.success(quizData))
                } catch {
                    completion(.failure(error))
                }
            case .failure(let error):
                completion(.failure(error))
            }
        }
    }
}




