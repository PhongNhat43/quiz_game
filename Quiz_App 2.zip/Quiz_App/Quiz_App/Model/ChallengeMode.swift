//
//  Challenge.swift
//  Quiz_App
//
//  Created by devsenior on 16/02/2024.
//

import Foundation


struct ChallengeMode {
    let title: String
    let image: String
    let urls: [String]
}

struct Challenge {
    var level: String
    var image: String
    var unlocked: Bool
}

