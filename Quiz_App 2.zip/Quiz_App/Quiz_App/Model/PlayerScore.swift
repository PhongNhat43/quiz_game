//
//  PlayerScore.swift
//  Quiz_App
//
//  Created by devsenior on 18/02/2024.
//

import Foundation

struct PlayerScore {
    var score: Int
}
