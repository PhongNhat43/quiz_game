//
//  PauseViewController.swift
//  Quiz_App
//
//  Created by devsenior on 23/02/2024.
//

import UIKit

protocol PlayViewControllerDelegate {
    func toggleSoundEffects()
    func quitGame()
    func resumeGame()
}

class PauseViewController: UIViewController {
    
    @IBOutlet weak var soundBtn: UIButton!
    @IBOutlet weak var pauseView: UIView!
    var isSoundOn: Bool = true
    var delegate: PlayViewControllerDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpBtn()
    }
    
    override func viewDidLayoutSubviews() {
        setUpUI()
    }
    
    func setUpBtn() {
        isSoundOn = UserDefaults.standard.bool(forKey: Constants.isSoundOn)
        updateSoundButtonState()
        soundBtn.setImage(UIImage(named: "off_sound"), for: .normal)
        soundBtn.setImage(UIImage(named: "on_sound"), for: .selected)
    }
    
    func setUpUI() {
        pauseView.layer.cornerRadius = 10
        pauseView.layer.borderWidth = 2
    }
   
    func updateSoundButtonState() {
        soundBtn.isSelected = !isSoundOn
    }

    @IBAction func didTapSoundButton(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
        isSoundOn = !sender.isSelected
        // Lưu trạng thái của soundBtn vào UserDefaults
        UserDefaults.standard.set(isSoundOn, forKey: Constants.isSoundOn)
        delegate?.toggleSoundEffects()
    }

       @IBAction func didTapQuitButton(_ sender: UIButton) {
           dismiss(animated: true) { [weak self] in
                self?.delegate?.quitGame()
           }
       }

       @IBAction func didTapResumeButton(_ sender: UIButton) {
           delegate?.resumeGame()
           dismiss(animated: true, completion: nil)
       }
}


