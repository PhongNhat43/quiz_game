//
//  MenuViewController.swift
//  Quiz_App
//
//  Created by devsenior on 14/02/2024.
//
import UIKit

class MenuViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    
    var viewModel = QuizViewModel()
       
    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel.onDataFetched = { [weak self] in
           DispatchQueue.main.async {
                self?.tableView.reloadData()
          }
      }
      setupTable()
    }
    
    func setupTable() {
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(ChallengeTableViewCell.nib(), forCellReuseIdentifier: ChallengeTableViewCell.indentifier)
        navigationController?.navigationBar.isHidden = true
    }
}

extension MenuViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.numberOfChallengeMode()
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: ChallengeTableViewCell.indentifier, for: indexPath) as? ChallengeTableViewCell else {
            return UITableViewCell()
        }
      
        if let challenge = viewModel.challengeMode(at: indexPath.row) {
            cell.configure(data: challenge)
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return Constants.heightMenu
    }
}

extension MenuViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let challengeMode = viewModel.challengeMode(at: indexPath.row) {
            let challengeVC = ChanllengeViewController()
            challengeVC.selectedChallengeMode = challengeMode 
            navigationController?.pushViewController(challengeVC, animated: true)
        }
    }
}
