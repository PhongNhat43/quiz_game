//
//  PlayViewController.swift
//  Quiz_App
//
//  Created by devsenior on 15/02/2024.
//

import UIKit
import AVFoundation
import Toast_Swift
class PlayViewController: UIViewController {
    
    @IBOutlet private weak var scoreLabel: UILabel!
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var countDownLabel: UILabel!
    @IBOutlet private weak var heartsLabel: UILabel!
    @IBOutlet weak var pauseLabel: UIButton!
    @IBOutlet weak var addTimeLabel: UIButton!
    @IBOutlet weak var subjectLabel: UILabel!
    @IBOutlet weak var levelLabel: UILabel!
    
    // Khởi tạo QuizViewModel
    var viewModel = QuizViewModel()
    var urls: [String]?
    var countdownTimer: Timer?
    var remainingTime = 30
    var hearts = 3
    var audioPlayer: AVAudioPlayer?
    var effectPlayer: AVAudioPlayer?
    var isSoundEnabled: Bool = true
    var selectedLevel: Int?
    var selectedChallengeMode: ChallengeMode?
    var selectedChallenge: Challenge?
    var loadingIndicator: UIActivityIndicatorView?
    var musicEnabled: Bool = true
    var soundEffectsEnabled: Bool = true

    override func viewDidLoad() {
        super.viewDidLoad()
        setupCollectionView()
        startCountdown()
        playCountdownSound()
        setUpNavigation()
        updateHeartsLabel()
        updateScoreLabel()
        updateStateSound()
        if let level = selectedLevel {
            showLoadingIndicator()
            fetchQuizData(for: level, completion: {
                self.hideLoadingIndicator()
                self.showUIElements()
          })
        }
    }
    
    func updateStateSound() {
        isSoundEnabled = UserDefaults.standard.bool(forKey: Constants.isSoundEnabled)
        // Áp dụng trạng thái bật/tắt âm thanh
        if isSoundEnabled {
            audioPlayer?.play()
            effectPlayer?.play()
        } else {
            audioPlayer?.pause()
            effectPlayer?.pause()
        }
    }
    
    func updateHeartsLabel() {
        heartsLabel.text = "Hearts: \(hearts)"
    }
    
    func resetHearts() {
        hearts = 3
        updateHeartsLabel()
    }
    
    func handleWrongAnswer() {
        hearts -= 1
        updateHeartsLabel()
        
        if hearts == 0 {
            // Khi số lượng hearts là 0, hiển thị thông báo game over
            showGameOverAlert()
            return
        }
    }

    func moveToNextQuestionOrEndGame() {
        let currentIndexPath = collectionView.indexPathsForVisibleItems.first
        guard let currentIndexPath = currentIndexPath else { return }
        
        let nextIndexPath = IndexPath(row: currentIndexPath.row + 1, section: currentIndexPath.section)
        if nextIndexPath.row < viewModel.numberOfQuestions() {
            // Có câu hỏi tiếp theo, chuyển đến câu hỏi tiếp theo
            collectionView.scrollToItem(at: nextIndexPath, at: .centeredHorizontally, animated: true)
        }
        if nextIndexPath.row > viewModel.numberOfQuestions() {
            showVictoryAlert()
            return
        }
    }
    
    func updateScoreLabel() {
        let totalScore = SqliteManager.shared.getTotalScore()
        scoreLabel.text = "Score: \(totalScore)"
    }
    
    func showLoadingIndicator() {
        loadingIndicator = UIActivityIndicatorView(style: .large)
        loadingIndicator?.center = self.view.center
        self.view.addSubview(loadingIndicator!)
        loadingIndicator?.startAnimating()
        collectionView.isUserInteractionEnabled = false
        hideUIElements()
    }

    func hideLoadingIndicator() {
        loadingIndicator?.stopAnimating()
        loadingIndicator?.removeFromSuperview()
        collectionView.isUserInteractionEnabled = true
    }
    
    func hideUIElements() {
        scoreLabel.isHidden = true
        heartsLabel.isHidden = true
        countDownLabel.isHidden = true
        subjectLabel.isHidden = true
        levelLabel.isHidden = true
    }

    func showUIElements() {
        scoreLabel.isHidden = false
        heartsLabel.isHidden = false
        countDownLabel.isHidden = false
        subjectLabel.isHidden = false
        levelLabel.isHidden = false
    }
    
    func setUpNavigation() {
        subjectLabel.text = selectedChallengeMode?.title
        levelLabel.text = selectedChallenge?.level
        navigationController?.navigationBar.isHidden = true
    }
    
    func playCountdownSound() {
        guard isSoundEnabled, let soundURL = Bundle.main.url(forResource: "Countdown", withExtension: "mp3") else {
            print("Sound file not found or sound is disabled")
            return
        }
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: soundURL)
            audioPlayer?.play()
        } catch {
            print("Error playing sound: \(error.localizedDescription)")
        }
    }

    func playSound(named soundName: String) {
        guard isSoundEnabled, let soundURL = Bundle.main.url(forResource: soundName, withExtension: "mp3") else {
            print("Sound file not found or sound is disabled")
            return
        }
        do {
            effectPlayer = try AVAudioPlayer(contentsOf: soundURL)
            effectPlayer?.play()
        } catch {
            print("Error playing sound: \(error.localizedDescription)")
        }
    }

    func setupCollectionView() {
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.register(PlayCollectionViewCell.nib(), forCellWithReuseIdentifier: PlayCollectionViewCell.indentifier)
        collectionView.isScrollEnabled = false
    }
    
    // Lưu trạng thái unlocked của Level vào UserDefaults
    func saveUnlockedStateForLevel(level: Int) {
        UserDefaults.standard.set(true, forKey: "unlocked_\(level)")
    }

    // Kiểm tra trạng thái unlocked của Level từ UserDefaults
    func isLevelUnlocked(level: Int) -> Bool {
        return UserDefaults.standard.bool(forKey: "unlocked_\(level)")
    }
    
    func startCountdown() {
        countdownTimer?.invalidate()
        countdownTimer = nil

        countdownTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { [weak self] timer in
            guard let self = self else {
                timer.invalidate()
                return
            }
            self.remainingTime -= 1
            self.countDownLabel.text = "\(self.remainingTime)"
            if self.remainingTime <= 0 {
                timer.invalidate()
                self.remainingTime = 0
                self.countDownLabel.text = "0"
                if self.hearts <= 0 {
                    self.showGameOverAlert()
                    return
                }
                if self.hearts >= 0 {
                    self.handleWrongAnswer()
                    return
                }
            }
        }
    }
     deinit {
         countdownTimer?.invalidate()
     }
    
    func fetchQuizData(for level: Int, completion: @escaping () -> Void) {
           viewModel.onDataFetched = { [weak self] in
               DispatchQueue.main.async {
                   self?.collectionView.reloadData()
                   completion()
               }
           }
           viewModel.fetchQuizData(for: level, urls: urls!)
    }
    
    func resetQuiz(for level: Int) {
        showLoadingIndicator()
        fetchQuizData(for: level) {
            self.hideLoadingIndicator()
            self.resetUIForNewLevel()
        }
    }

    func showGameOverAlert() {
        let alert = UIAlertController(title: "Failed", message: "Game Over", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Try Again", style: .default, handler: { [weak self] _ in
            guard let strongSelf = self else { return }
          // Hiển thị loading indicator
            strongSelf.countdownTimer?.invalidate()
            strongSelf.countdownTimer = nil
            strongSelf.resetHearts()
            strongSelf.showLoadingIndicator()
            strongSelf.showUIElements()
            if let level = strongSelf.selectedLevel {
                strongSelf.fetchQuizData(for: level) {
                    strongSelf.hideLoadingIndicator()
                    strongSelf.resetUIForNewLevel()
                }
            }
        }))
        alert.addAction(UIAlertAction(title: "Quit", style: .cancel, handler: { [weak self] _ in
            self?.navigationController?.popViewController(animated: true)
        }))
        present(alert, animated: true, completion: nil)
    }
    
    func showVictoryAlert() {
        let alert = UIAlertController(title: "Victory", message: "Unlock Level Up!", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Next Level", style: .default, handler: { [weak self] _ in
            guard let self = self else { return }
            
            if let nextLevel = self.selectedLevel.map({ $0 + 1 }) {
                self.saveUnlockedStateForLevel(level: nextLevel)
                self.selectedLevel = nextLevel
                self.viewModel.updateChallenges(currentLevelCompleted: nextLevel - 1)
                self.fetchQuizData(for: nextLevel, completion: {})
                self.resetUIForNewLevel()
                self.setUpNavigation()
            }
        }))
        present(alert, animated: true, completion: nil)
    }
    
    func resetUIForNewLevel() {
        // Đặt lại thời gian đếm ngược và cập nhật countDownLabel
        remainingTime = 30
        countDownLabel.text = "\(remainingTime)"
        // Đặt lại Timer
        countdownTimer?.invalidate()
        startCountdown()
        // Dừng và reset âm thanh (nếu cần)
        audioPlayer?.stop()
        audioPlayer?.currentTime = 0
        playCountdownSound()
        // Cuộn collectionView về đầu một cách mượt mà
        collectionView.scrollToItem(at: IndexPath(item: 0, section: 0), at: .top, animated: true)
        setUpNavigation()
    }
    
    func handleCorrectAnswer() {
        // Sau đó, chuyển sang câu hỏi tiếp theo hoặc kết thúc trò chơi
        moveToNextQuestionOrEndGame()
    }
    
    @IBAction func didTapPauseBtn(_ sender: Any) {
        // Dừng bộ đếm thời gian và âm thanh
        countdownTimer?.invalidate()
        audioPlayer?.pause()
        
        let pauseViewController = PauseViewController()
        pauseViewController.modalPresentationStyle = .overCurrentContext
        pauseViewController.modalTransitionStyle = .crossDissolve
        pauseViewController.delegate = self
        // Hiển thị menu pause
        present(pauseViewController, animated: true, completion: nil)
    }
    
    @IBAction func didTapAddTimeBtn(_ sender: Any) {
        // Lấy tổng điểm hiện tại
        let totalScore = SqliteManager.shared.getTotalScore()
        if totalScore >= 50 {
            SqliteManager.shared.addScore(points: -50)
            remainingTime += 20
            countDownLabel.text = "\(remainingTime)"
            updateScoreLabel()
            return
        }
        if totalScore <= 50 {
            self.view.makeToast("Không đủ điểm để thêm thời gian!")
            print("Không đủ điểm để thêm thời gian!")
            return
        }
    }
}
extension PlayViewController: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return viewModel.numberOfQuestions()
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: PlayCollectionViewCell.indentifier, for: indexPath) as? PlayCollectionViewCell,
              let questionData = viewModel.question(at: indexPath.row) else {
            return UICollectionViewCell()
        }
        cell.configure(data: questionData, currentIndex: indexPath.row, totalQuestions: viewModel.numberOfQuestions())
        return cell
    }
}
extension PlayViewController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.width, height: collectionView.frame.height)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
}

extension PlayViewController: UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        guard let quizCell = cell as? PlayCollectionViewCell else { return }
        remainingTime = 30
        countDownLabel.text = "\(remainingTime)"
        audioPlayer?.stop()
        audioPlayer?.currentTime = 0
        playCountdownSound()
        quizCell.onAnswerSelected = { [weak self] isCorrect in
            guard let self = self else { return }
            
            if isCorrect {
                SqliteManager.shared.addScore(points: 10)
                self.updateScoreLabel()
                self.handleCorrectAnswer()
                self.playSound(named: isCorrect ? "right" : "wrong")
                
                let nextIndexPath = IndexPath(row: indexPath.row + 1, section: indexPath.section)
                if nextIndexPath.row < self.viewModel.numberOfQuestions() {
                    collectionView.scrollToItem(at: nextIndexPath, at: .centeredHorizontally, animated: true)
                } else {
                    self.view.makeToast("Bạn đã chiến thắng")
                    self.showVictoryAlert()
                }
            } else {
                self.playSound(named: "wrong")
                self.handleWrongAnswer()
            }
        }
    }
}

extension PlayViewController: PlayViewControllerDelegate {
    func toggleSoundEffects() {
            isSoundEnabled = !isSoundEnabled // Đảo ngược trạng thái bật/tắt âm thanh
        UserDefaults.standard.set(isSoundEnabled, forKey: Constants.isSoundEnabled)
            if isSoundEnabled {
                audioPlayer?.play()
                effectPlayer?.play()
            } else {
                audioPlayer?.pause()
                effectPlayer?.pause()
            }
        }
    
    func quitGame() {
        navigationController?.popViewController(animated: true)
    }
    func resumeGame() {
        startCountdown()
    }
}
