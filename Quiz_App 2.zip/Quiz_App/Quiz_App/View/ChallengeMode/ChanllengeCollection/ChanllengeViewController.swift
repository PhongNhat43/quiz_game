//
//  ChanllengeViewController.swift
//  Quiz_App
//
//  Created by devsenior on 16/02/2024.
//

import UIKit
import Toast_Swift
class ChanllengeViewController: UIViewController {

    @IBOutlet weak var collectionView: UICollectionView!
    var viewModel = QuizViewModel()
    var selectedChallengeMode: ChallengeMode?
    override func viewDidLoad() {
        super.viewDidLoad()
        setupCollectionView()
        NotificationCenter.default.addObserver(self, selector: #selector(handleChallengeUpdate), name: NSNotification.Name("ChallengeUpdated"), object: nil)
        viewModel.onDataFetched = { [weak self] in
           DispatchQueue.main.async {
                self?.collectionView.reloadData()
           }
        }
    }

    @objc func handleChallengeUpdate() {
        collectionView.reloadData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        viewModel.refreshChallengesStatus()
        collectionView.reloadData()
        navigationController?.navigationBar.isHidden = false
    }
 
    
    func setupCollectionView() {
        self.view.backgroundColor = .gray
        collectionView.layer.cornerRadius = 15
        collectionView.dataSource = self
        collectionView.delegate = self
        collectionView.register(ChanllengeCollectionViewCell.nib(), forCellWithReuseIdentifier: ChanllengeCollectionViewCell.indentifier)
    }
}

extension ChanllengeViewController: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return viewModel.numberOfChallenges()
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: ChanllengeCollectionViewCell.indentifier, for: indexPath) as? ChanllengeCollectionViewCell else {
            return UICollectionViewCell()
        }
        if let challenge = viewModel.challenge(at: indexPath.row) {
            cell.configure(data: challenge)
        }
        return cell
    }
}

extension ChanllengeViewController: UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        guard let challenge = viewModel.challenge(at: indexPath.row), challenge.unlocked else {
            self.view.makeToast("Level này chưa được mở khoá.")
                print("Level này chưa được mở khoá.")
                return
            }
            
            let playVC = PlayViewController(nibName: "PlayViewController", bundle: nil)
            playVC.selectedLevel = indexPath.row + 1
            playVC.selectedChallengeMode = selectedChallengeMode
            playVC.selectedChallenge = challenge
            if let urls = selectedChallengeMode?.urls {
                playVC.urls = urls // Truyền mảng URL phù hợp vào PlayViewController
            }
            
            if let navigationController = self.navigationController {
                navigationController.pushViewController(playVC, animated: true)
            } else {
                self.present(playVC, animated: true, completion: nil)
            }
    }
}

extension ChanllengeViewController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.width, height: collectionView.frame.height)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }

}
