//
//  FristViewController.swift
//  Quiz_App
//
//  Created by devsenior on 24/02/2024.
//

import UIKit

class FristViewController: UIViewController {

    @IBOutlet weak var playView: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewDidLayoutSubviews() {
        playView.layer.cornerRadius = 10
        playView.layer.borderWidth = 5
        playView.layer.borderColor = UIColor.black.cgColor
    }

    @IBAction func didTapPlayButton(_ sender: Any) {
        let vc = MenuViewController(nibName: "MenuViewController", bundle: nil)
        navigationController?.pushViewController(vc, animated: true)
    }
    
}
