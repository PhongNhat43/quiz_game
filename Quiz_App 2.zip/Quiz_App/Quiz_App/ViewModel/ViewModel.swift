//
//  ViewModel.swift
//  Quiz_App
//
//  Created by devsenior on 14/02/2024.
//


import Foundation

class QuizViewModel {
    private var quiz: Quiz?

    private var challengeMode: [ChallengeMode] = [
        ChallengeMode(title: "Film", image: "film_image", urls: [Constants.filmUrl_lv1, Constants.filmUrl_lv2, Constants.filmUrl_lv3, Constants.filmUrl_lv4, Constants.filmUrl_lv5]),
           ChallengeMode(title: "Music", image: "music_image", urls: [Constants.musicUrl_lv1, Constants.musicUrl_lv2, Constants.musicUrl_lv3, Constants.musicUrl_lv4, Constants.musicUrl_lv5]),
        ChallengeMode(title: "Television", image: "television_image", urls: [Constants.tvUrl_lv1, Constants.tvUrl_lv2, Constants.tvUrl_lv3, Constants.tvUrl_lv4, Constants.tvUrl_lv5]),
        ChallengeMode(title: "History", image: "history_image", urls: [Constants.historyUrl_lv1, Constants.historyUrl_lv2, Constants.historyUrl_lv3, Constants.historyUrl_lv4, Constants.historyUrl_lv5])
    ]
    
     func numberOfChallengeMode() -> Int {
         return challengeMode.count
     }

     func challengeMode(at index: Int) -> ChallengeMode? {
         guard index < challengeMode.count else { return nil }
         return challengeMode[index]
     }
    
    //challengs
    private var challengs: [Challenge] = [
        Challenge(level: "Level 1", image: "ideas", unlocked: true),
        Challenge(level: "Level 2", image: "ideas", unlocked: false),
        Challenge(level: "Level 3", image: "ideas", unlocked: false),
        Challenge(level: "Level 4", image: "ideas", unlocked: false),
        Challenge(level: "Level 5", image: "ideas", unlocked: false),
    ]
    
    func numberOfChallenges() -> Int {
        return challengs.count
    }

    func challenge(at index: Int) -> Challenge? {
        guard index < challengs.count else { return nil }
        return challengs[index]
    }
    
    func unlockNextLevel(currentLevelIndex: Int) {
        // Kiểm tra xem level hiện tại có phải là level cuối cùng không
        guard currentLevelIndex < challengs.count - 1 else { return }
        // Mở khoá level tiếp theo
        challengs[currentLevelIndex + 1].unlocked = true
        // Gọi onDataFetched để thông báo cho ViewController cập nhật UI
        onDataFetched?()
    }
    
    var onDataFetched: (() -> Void)?

    func fetchQuizData(for level: Int, urls: [String]) {
        guard level - 1 < urls.count else { return }
        
        APIHandler().getData(from: urls[level - 1]) { [weak self] result in
            switch result {
            case .success(let quizData):
                self?.quiz = quizData
                self?.onDataFetched?()
            case .failure(let error):
                print(error)
            }
        }
    }
    
    // Hàm để lấy số lượng câu hỏi
    func numberOfQuestions() -> Int {
        return quiz?.results.count ?? 0
    }
    // Hàm để lấy câu hỏi cụ thể
    func question(at index: Int) -> Question? {
        return quiz?.results[index]
    }
    
    func updateChallenges(currentLevelCompleted index: Int) {
        if index < challengs.count - 1 {
            challengs[index + 1].unlocked = true
        }
        onDataFetched?()
    }
    
    func refreshChallengesStatus() {
        for (index, _) in challengs.enumerated() {
            // Đảm bảo level 1 luôn được mở khoá
            if index == 0 {
                challengs[index].unlocked = true
            } else {
                let isUnlocked = UserDefaults.standard.bool(forKey: "unlocked_\(index + 1)")
                challengs[index].unlocked = isUnlocked
            }
        }
    }
}
