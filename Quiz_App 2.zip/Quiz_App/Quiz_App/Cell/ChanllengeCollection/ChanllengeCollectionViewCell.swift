//
//  ChanllengeCollectionViewCell.swift
//  Quiz_App
//
//  Created by devsenior on 16/02/2024.
//

import UIKit

class ChanllengeCollectionViewCell: UICollectionViewCell {
    
    static let indentifier = "ChanllengeCollectionViewCell"
    static func nib() -> UINib {
       return UINib(nibName: "ChanllengeCollectionViewCell", bundle: nil)
    }
    @IBOutlet private weak var fullView: UIView!
    @IBOutlet private weak var levelLabel: UILabel!
    @IBOutlet private weak var quizImage: UIImageView!
    
    let overlayView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    let lockImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        return imageView
    }()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        setUpUI()
        
    }
    
    func setUpUI() {
        fullView.addSubview(overlayView)
        quizImage.addSubview(lockImageView)
        lockImageView.contentMode = .scaleAspectFill
              
        NSLayoutConstraint.activate([
            overlayView.topAnchor.constraint(equalTo: fullView.topAnchor),
            overlayView.bottomAnchor.constraint(equalTo: fullView.bottomAnchor),
            overlayView.leadingAnchor.constraint(equalTo: fullView.leadingAnchor),
            overlayView.trailingAnchor.constraint(equalTo: fullView.trailingAnchor),
                  
            lockImageView.centerXAnchor.constraint(equalTo: quizImage.centerXAnchor),
            lockImageView.centerYAnchor.constraint(equalTo: quizImage.centerYAnchor)
        ])
    }
    
    func configure(data: Challenge) {
        levelLabel.text = data.level
        quizImage.image = UIImage(named: data.image)
        
        if data.unlocked {
            overlayView.backgroundColor = UIColor.clear
            lockImageView.image = nil
        } else {
            overlayView.backgroundColor = UIColor.black.withAlphaComponent(0.2)
            lockImageView.image = UIImage(named: "lock")
        }
    }
}
