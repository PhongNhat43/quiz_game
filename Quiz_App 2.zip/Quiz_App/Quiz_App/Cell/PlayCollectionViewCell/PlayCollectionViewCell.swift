//
//  PlayCollectionViewCell.swift
//  Quiz_App
//
//  Created by devsenior on 14/02/2024.
//

import UIKit
class PlayCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet private weak var topView: UIView!
    @IBOutlet private weak var countLaBel: UILabel!
    @IBOutlet private weak var questionLabel: UILabel!
    @IBOutlet private weak var answerBtnA: UIButton!
    @IBOutlet private weak var answerBtnB: UIButton!
    @IBOutlet private weak var answerBtnC: UIButton!
    @IBOutlet private weak var answerBtnD: UIButton!
    
    private var correctAnswer: String?
    var onAnswerSelected: ((Bool) -> Void)?
    static let indentifier = "PlayCollectionViewCell"
    
    static func nib() -> UINib {
       return UINib(nibName: "PlayCollectionViewCell", bundle: nil)
    }

    override func awakeFromNib() {
        super.awakeFromNib()
        setupUI()
    }
    
    func setupUI() {
        topView.layer.cornerRadius = 10
        topView.layer.borderWidth = 5
        topView.layer.borderColor = UIColor.green.cgColor
        
        answerBtnA.layer.cornerRadius = 50
        answerBtnA.layer.borderWidth = 5
        answerBtnA.layer.borderColor = UIColor.black.cgColor
        
        answerBtnB.layer.cornerRadius = 50
        answerBtnB.layer.borderWidth = 5
        answerBtnB.layer.borderColor = UIColor.black.cgColor
        
        answerBtnC.layer.cornerRadius = 50
        answerBtnC.layer.borderWidth = 5
        answerBtnC.layer.borderColor = UIColor.black.cgColor
        
        answerBtnD.layer.cornerRadius = 50
        answerBtnD.layer.borderWidth = 5
        answerBtnD.layer.borderColor = UIColor.black.cgColor
    }
    
    @IBAction func answerButtonTapped(_ sender: UIButton) {
        guard let answer = sender.titleLabel?.text else { return }
        let isCorrect = answer == correctAnswer
        onAnswerSelected?(isCorrect)
        
        if answer == correctAnswer {
            // Hiển thị UIAlert với thông điệp "Correct"
            showAlert(withTitle: "Correct", message: "You're right!", actions: [UIAlertAction(title: "OK", style: .default, handler: { _ in
            })])
        } else {

        }
    }

    private func showAlert(withTitle title: String, message: String, actions: [UIAlertAction]) {
        if let viewController = self.window?.rootViewController {
            let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
            actions.forEach { alert.addAction($0) }
            viewController.present(alert, animated: true, completion: nil)
        }
    }
    
    func configure(data: Question, currentIndex: Int, totalQuestions: Int) {
        questionLabel.text = data.question
        self.correctAnswer = data.correctAnswer
        countLaBel.text = "\(currentIndex + 1)/\(totalQuestions)"
        
        // Trộn đáp án đúng và đáp án sai
        var answers = data.incorrectAnswers
        answers.insert(data.correctAnswer, at: Int.random(in: 0...answers.count))
        
        // Đảm bảo rằng có đủ đáp án để gán cho các nút
        guard answers.count >= 4 else { return }
        
        // Gán đáp án cho các nút
        answerBtnA.setTitle(answers[0], for: .normal)
        answerBtnB.setTitle(answers[1], for: .normal)
        answerBtnC.setTitle(answers[2], for: .normal)
        answerBtnD.setTitle(answers[3], for: .normal)
        
        // Cấu hình thêm cho các nút nếu cần
        [answerBtnA, answerBtnB, answerBtnC, answerBtnD].forEach { button in
            button?.layer.cornerRadius = 8
            button?.titleLabel?.adjustsFontSizeToFitWidth = true
        }
    }
}
