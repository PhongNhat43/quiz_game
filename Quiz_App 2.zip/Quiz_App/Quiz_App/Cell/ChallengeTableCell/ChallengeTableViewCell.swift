//
//  ChallengeTableViewCell.swift
//  Quiz_App
//
//  Created by devsenior on 16/02/2024.
//

import UIKit

class ChallengeTableViewCell: UITableViewCell {
    
    static let indentifier = "ChallengeTableViewCell"
    static func nib() -> UINib {
       return UINib(nibName: "ChallengeTableViewCell", bundle: nil)
    }

    @IBOutlet private weak var viewCell: UIView!
    @IBOutlet private weak var subjectTitleLabel: UILabel!
    @IBOutlet private weak var subjectImageView: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    func setupUI() {
        subjectImageView.layer.cornerRadius = 30
        subjectImageView.layer.borderWidth = 5
        subjectImageView.layer.borderColor = UIColor.systemYellow.cgColor
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    override func layoutSubviews() {
        setupUI()
    }
    
    func configure(data: ChallengeMode) {
        subjectTitleLabel.text = data.title
        subjectImageView.image = UIImage(named: data.image)
    }
}
